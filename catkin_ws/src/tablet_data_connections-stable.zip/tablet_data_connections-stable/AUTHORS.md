# Authors and Contributors

tablet_data_connections package was designed and developed by the Social Robots Group at Robotics Lab, UC3M (Spain).

### Current Team

* [sergiogon](http://asimov.uc3m.es/sergiogon) (developer, maintainer)
* [Miguel A. Salichs](http://roboticslab.uc3m.es/roboticslab/people/ma-salichs) (director)


### Thanks

[See all Github contributors](http://asimov.uc3m.es/devices/tablet_data_connections/contributors)

