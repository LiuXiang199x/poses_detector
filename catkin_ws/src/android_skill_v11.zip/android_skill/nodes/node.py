#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Miguel Angel Quispe Flores"
__copyright__ = "Social Robots Group. Robotics Lab. University Carlos III of Madrid"
__credits__ = ["Miguel Angel Quispe Flores"]
__license__ = "LEUC3M v1.0"
__version__ = "0.0.0"
__maintainer__ = "Miguel Angel Quispe Flores"
__email__ = "mquispe@pa.uc3m.es"
__status__ = "Development"


import rospy
from android_skill.android import AndroidSkill

pkg_name = "android_skill" # Package name

if __name__ == '__main__':
    try:
        # start the node
        rospy.init_node(pkg_name)

        # create and spin the node
        node = AndroidSkill()

        rospy.spin()
    except rospy.ROSInterruptException:
        pass
