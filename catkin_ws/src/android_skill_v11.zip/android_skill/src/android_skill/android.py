#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Miguel Angel Quispe Flores"
__copyright__ = "Social Robots Group. Robotics Lab. University Carlos III of Madrid"
__credits__ = ["Miguel Angel Quispe Flores"]
__license__ = "LEUC3M v1.0"
__version__ = "0.0.0"
__maintainer__ = "Miguel Angel Quispe Flores"
__email__ = "mquispe@pa.uc3m.es"
__status__ = "Development"

# Import libs
import sys
import os
import rospkg
import rospy
import roslib
import android_skill.msg
import actionlib

from random import choice, shuffle, randint

from skill.skill import Skill, ActionlibException, CONDITIONAL
from std_msgs.msg import String, Bool

from interaction_utils.key_value_pairs import to_dict
from interaction_msgs.msg import CA, CaResult
from interaction_utils.ca_functions import *
#from dms_msgs.msg import ElicitorActivator

rospack = rospkg.RosPack()
pkg_name = 'android_skill'                
skill_name = 'android_skill' # Name of the package
app_name = 'android_app_spotify'
RATE = 0.2 # Sleep rate between loops


class AndroidSkill(Skill):

    """
    Quiz skill class.
    """

    # create messages that are used to publish feedback/result
    _feedback = android_skill.msg.AndroidFeedback()
    _result = android_skill.msg.AndroidResult()

    MAIN_MENU_LIST = ['activate_music_menu','activate_podcast_menu']
    MUSIC_MENU_LIST = ['activate_espaniola_menu','activate_romantica_menu','activate_clasica_menu','activate_contemporanea_menu']
    PODCAST_MENU_LIST = ['activate_noticias_menu','activate_deportes_menu','activate_historias_menu','activate_comedias_menu']

    SELECTION_ESPANIOLA_MUSIC = ['play_coplas_music','play_sevillanas_music','play_flamenco_music','play_jotas_music','play_zarzuelas_music']
    SELECTION_ROMANTICA_MUSIC = ['play_baladas_music','play_boleros_music','play_tangos_music','play_cantantes_recuerdo_music','play_canciones_recuerdo_music']
    SELECTION_CLASICA_MUSIC = ['play_piano_music','play_grandes_clasicos_music','play_orquesta_music','play_violin_music','play_relajante_music']
    SELECTION_CONTEMPORANEA_MUSIC = ['play_rock_music','play_pop_music','play_jazz_music','play_blues_music','play_bandas_sonoras_music']

    SELECTION_ACTUALIDAD_MENU = ["play_p1_actualidad","play_p2_actualidad","play_p3_actualidad","play_p4_actualidad","play_p5_actualidad"]
    SELECTION_DEPORTES_MENU = ["play_p1_deportes","play_p2_deportes","play_p3_deportes","play_p4_deportes","play_p5_deportes"]
    SELECTION_HISTORIAS_MENU = ["play_p1_historias","play_p2_historias","play_p3_historias","play_p4_historias","play_p5_historias"]
    SELECTION_COMEDIA_MENU = ["play_p1_comedia","play_p2_comedia","play_p3_comedia","play_p4_comedia","play_p5_comedia"]

    BACK_FOR_MENU = ["back_for_music_menu","back_for_podcast_menu",
    "back_for_espaniola_menu","back_for_romantica_menu","back_for_clasica_menu","back_for_contemporanea_menu"
    "back_for_actualidad_menu","back_for_deportes_menu","back_for_historias_menu","back_for_comedia_menu"]

    def __init__(self):
        """
        Init method.
        """

        # init the skill
        Skill.__init__(self, pkg_name, CONDITIONAL)

        # Class variables
        self._as = None # Action variable
        self.__skill_finished = False # Skill finished flag
        self.__app_state = None # Status of the android app

        self.__app_menu = None

        self._handshake_timer = None
        self.__active_cas = list() # Active ca list
        self.__waiting_answer = False # Waiting CAResult flag

        # Feedback values
        self.app_status = None # Actual status of the skill
        self.engagement = True # Engagement of the user
        self.percentage_completed = 0 # Percentage completed of the skill

    def create_msg_srv(self):
        """
        Defines publishers, subscribers, services and actions
        """

        # Publishers and Subscriber to handle the android/tablet app
        self.__pub_to_app_tablet = rospy.Publisher("message_order_app", String, queue_size=1)
        
        self.__app_listener = rospy.Subscriber(app_name+"/pc", String, self.__app_listCallback)
        self.__pub_to_app = rospy.Publisher(app_name+"/app", String, queue_size=1)

        # Publishers to handle CAs
        self.__pub_ca = rospy.Publisher("hri_manager/ca_activations", CA, queue_size=1)
        self.__deactivate_ca = rospy.Publisher("hri_manager/ca_deactivations", String, queue_size=1)
        #self.__emotional_elicitor_pub = rospy.Publisher("emotional_model/cognitive_activation", ElicitorActivator, queue_size=1)
        # Ca response subscriber
        self.__ca_sub = rospy.Subscriber("hri_manager/response", CaResult, self.__ca_cb)    
        
        # Skill conditional action definition
        if self._as is None:
            self._as = actionlib.SimpleActionServer(skill_name,
                                                    android_skill.msg.AndroidAction,
                                                    execute_cb=self.execute_cb,
                                                    auto_start=False)
            # Start the action server
            self._as.start()
            rospy.loginfo('[STARTING: %s]', pkg_name)

    def shutdown_msg_srv(self):
        """
        Deletes publishers, servers, services ans actions

        """

        # Set a log info
        rospy.loginfo("Exiting %s...", pkg_name)

        # Set status of skill
        self.app_status = "stop_ok"
        self.__build_feedback()
        
        # Shutting down subs
        self.__ca_sub.unregister()
        self.__app_listener.unregister()

        # Remove all active expressions
        self.__deactivate_cas()

    def __deactivate_cas(self):
        """
        Deactivate all expressions in list
        """

        rospy.loginfo("Deactivating CA list %s", str(self.__active_cas))
        # Deactivate all active expressions
        for ca in self.__active_cas:
            self.__deactivate_ca.publish(ca)
            self.__active_cas.remove(ca)
        
        self.__active_cas = list()

    def __ca_cb(self, ca_result):
        """
        Receives the execution results for the CAs
        @ input ca_result CaResult msg: result of the interaction
        """
        response = ("New response CA:\n" 
            + " ca_result.emitter: " + ca_result.emitter + "\n" 
            + " ca_result.ca_name: " + ca_result.ca_name + "\n"
            + " ca_result.result: " + ca_result.result + "\n")
        rospy.loginfo(response)

        values = to_dict(ca_result.values)

        rospy.loginfo(values)


        if ca_result.emitter == pkg_name and ca_result.ca_name in self.__active_cas and self.__waiting_answer:
            rospy.loginfo("New response received from HRI manager...")

            # Get the user response in a dict (tablet for example)
            if bool(values):
                ans = values['answer_value'].lower()
                rospy.loginfo("Received response: " + ans)
                if ca_result.result == 'succeeded':
                    if ca_result.ca_name == self.__active_cas[-1]:
                        rospy.loginfo(" state_transition [next state]")
                        self.menu_transition(ans)

            # Robot has said any sentence/question
            else:
                rospy.loginfo("Robot has said any sentence/question")
                if ca_result.result == 'succeeded':
                    if ca_result.ca_name == self.__active_cas[-1]:
                        rospy.loginfo(" state_transition [next state]")
                        self.state_transition()

            # Remove CA
            self.__active_cas.remove(ca_result.ca_name)
            self.__waiting_answer = False

    def resume_exec(self):
        """
        Function activated after receiving a resume from skill handler
        """

        rospy.loginfo("Skill %s resumed", pkg_name)
        self.app_status = 'resume_ok'

        # publish the feedback
        self.__build_feedback()

    def timerCallback(self,event):
        rospy.loginfo("timer finished...checking handshake")
        self._handshake_timer.shutdown()
        self._handshake_timer = None
        if self.__app_state == "waiting_hanshake_timer":
            self.__app_state = "handshaking_app"
        elif self.__app_state == "handshaked_correct":
            self.__app_state = "connected_app"

    def execute_cb(self, goal):
        """
        Callback to execute the action of dancing. 

        @param goal: message with the content.
        """
        self.__skill_finished = False
        self.__waiting_answer = False
        self.__app_menu = None
        # Init variables
        self._result.skill_result = android_skill.msg.AndroidResult().FAIL # Define skill result = FAIL

        if self._status == self.RUNNING:
            # Set a log info
            rospy.loginfo("Entering %s... and open app", pkg_name)
            self.__pub_to_app_tablet.publish("open_app/org.ros.android." + app_name)
            # Init variables
            # Set status of skill and send feedback
            self.app_status = "start_ok"
            self.__app_state = "starting_app"
            self.percentage_completed = 0
            self.engagement = True
            self.__build_feedback()

            # Main program of the skill
            try:
                # While the skill is not finished, execute loop maintaining active the skill
                while not self.__skill_finished:
                    # Check if there is a cancel request
                    if self._as.is_preempt_requested():
                        raise ActionlibException

                    if self.app_status in ['start_ok', 'resume_ok']:
                        if self.__app_state == "handshaking_app":
                            rospy.loginfo("Publishing handshaking robot app")
                            self.__pub_to_app.publish("handshaking_robot_app")
                            self._handshake_timer = rospy.Timer(rospy.Duration(1), self.timerCallback)
                            self.__app_state = "waiting_hanshake_timer"
                        else:
                            self.app_transitions_state()
                    # Sleep
                    rospy.sleep(RATE)

                if self.app_status not in ["completed_fail", "stop_ok"]:
                    # Deactivate all active expressions
                    self.__deactivate_cas()
                    # Update feedback vars and send it
                    self._result.skill_result = android_skill.msg.AndroidResult().SUCCESS
                    self.app_status = "completed_ok"
                    self.percentage_completed = 100
                    self.__build_feedback()

            except ActionlibException:
                # Deactivate all active expressions
                self.__deactivate_cas()
                # Activate last sentence
                #current_ca = self.__select_sentence("end_game")
                #self.__send_sentence(current_ca)
                # Skill cancelled or prempted
                rospy.logwarn('[%s] Preempted or cancelled' % pkg_name)
                # Set flags
                self.app_status = 'cancel_ok'
                self._result.skill_result = android_skill.msg.AndroidResult().FAIL 

                # publish the feedback
                self.__build_feedback()

        else:
            rospy.logwarn("[%s] Cannot send a goal when the skill is stopped" % pkg_name)
            # Deactivate all active expressions
            self.__deactivate_cas()
            # ERROR
            self._result.skill_result = android_skill.msg.AndroidResult().ERROR
            # publish the feedback
            self.app_status = "start_fail"
            self.__build_feedback()

        rospy.loginfo("Publishing result and ending skill...")
        # publish the result
        if self._result.skill_result == android_skill.msg.AndroidResult().SUCCESS:
            # SUCCESS
            self._as.set_succeeded(self._result)
        elif self._result.skill_result == android_skill.msg.AndroidResult().FAIL:
            # FAIL
            self._as.set_preempted(self._result)
        elif self._result.skill_result == android_skill.msg.AndroidResult().ERROR:
            # ERROR
            self._as.set_aborted(self._result)

    def pause_exec(self):
        """
        Function activated after receiving a pause from skill handler
        """

        rospy.loginfo("Skill %s paused", pkg_name)
        self.app_status = 'pause_ok'

        # publish the feedback
        self.__build_feedback()

        # Remove all active expressions
        self.__deactivate_cas()

    def __build_feedback(self):
        """
        Method which builds and published the feedback of the skill
        """

        # For every field of feedback, set class same value
        for feed in dir(self._feedback):
            if feed in vars(self):
                setattr(self._feedback, feed, getattr(self, feed))
        # publish the feedback
        self._as.publish_feedback(self._feedback)

    def __app_listCallback(self, msg):
        """
        Receives the msg from android app 
        @ input msg string msg: orders from android app
        """
        rospy.loginfo("msg: %s", msg.data)
        if msg.data == "app_completed_ok":
            self.__app_state = "end_app"

        elif msg.data == "goal_completed":
            self.__app_state = "close_app"

        elif msg.data == "connected_ok":
            self.__app_state = "handshaked_correct"

        elif msg.data == "executing_main_menu":
            self.__app_state = "executing_main_menu"


    ###################################################################
    def app_transitions_state(self):


        if self.__app_state == "end_app":
            self.__skill_finished = True
        else:
            if self.__app_state == "starting_app":
                self.__app_state = "handshaking_app"
                rospy.loginfo("new __app_state: %s", self.__app_state)

            elif self.__app_state == "close_app":
                self.__app_state = "closing_app"
                rospy.loginfo("new __app_state: %s", self.__app_state)
                self.__pub_to_app.publish("R_FINISH_APP")


            elif self.__app_state == "connected_app":
                self.__app_state = "executing_welcome"
                rospy.loginfo("new __app_state: %s", self.__app_state)
                self.say_ca_msg(t='Bienvenido a la aplicación de Spotifai.', ca_type='sentence', etts_type='welcome')
                self.__waiting_answer = True

            elif self.__app_state == "activate_main_menu":
                self.__app_state = "activating_main_menu"
                rospy.loginfo("new __app_state: %s", self.__app_state)
                self.__pub_to_app.publish("R_SCRPTCONNECTED")

                t = "Elige lo que quieras escuchar por pantalla."
                menu_value = "Música|Podcast|Salir"
                menu_type = "text"
                self.tablet_ca_msg(t=t, msg_type="main_menu", menu_value=menu_value, menu_type=menu_type)
                self.__app_menu = "MAIN_MENU"
                rospy.loginfo("__app_menu: " + self.__app_menu)
                self.__waiting_answer = True

            elif self.__app_state in self.MAIN_MENU_LIST:
                self.app_state_MAIN_MENU()

            elif self.__app_state in self.MUSIC_MENU_LIST:
                self.app_state_MUSIC_MENU()

            elif self.__app_state in self.PODCAST_MENU_LIST:
                self.app_state_PODCAST_MENU()

            elif self.__app_state in self.SELECTION_ESPANIOLA_MUSIC:
                self.app_state_M_ESPANIOLA()

            elif self.__app_state in self.SELECTION_ROMANTICA_MUSIC:
                self.app_state_M_ROMANTICA()

            elif self.__app_state in self.SELECTION_CLASICA_MUSIC:
                self.app_state_M_CLASICA()

            elif self.__app_state in self.SELECTION_CONTEMPORANEA_MUSIC:
                self.app_state_M_CONTEMPORANEA()

            elif self.__app_state in self.SELECTION_ACTUALIDAD_MENU:
                self.app_state_P_ACTUALIDAD()

            elif self.__app_state in self.SELECTION_DEPORTES_MENU:
                self.app_state_P_DEPORTES()

            elif self.__app_state in self.SELECTION_HISTORIAS_MENU:
                self.app_state_P_HISTORIAS()

            elif self.__app_state in self.SELECTION_COMEDIA_MENU:
                self.app_state_P_COMEDIA()

            elif self.__app_state in self.BACK_FOR_MENU:
                self.app_state_BACK_FOR_MENU()


    def app_state_MAIN_MENU(self):
        if self.__app_state ==  "activate_music_menu":
            self.__app_state = "activating_music_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_music_menu()
        elif self.__app_state == "activate_podcast_menu":
            self.__app_state = "activating_podcast_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_podcast_menu()

    def app_state_BACK_FOR_MENU(self):
        if self.__app_menu == "MUSIC_MENU" or self.__app_menu == "PODCAST_MENU":
            rospy.loginfo("going back to main_menu")
            self.__app_state = "activate_main_menu"
        elif self.__app_menu == "ESPANIOLA_MENU" or self.__app_menu == "ROMANTICA_MENU" or self.__app_menu == "CLASICA_MENU" or self.__app_menu == "CONTEMPORANEA_MENU":
            rospy.loginfo("going back to music_menu")
            self.__app_state = "activate_music_menu"
        elif self.__app_menu == "NOTICIAS_MENU" or self.__app_menu == "DEPORTES_MENU" or self.__app_menu == "HISTORIAS_MENU" or self.__app_menu == "COMEDIA_MENU":
            rospy.loginfo("going back to podcast_menu")
            self.__app_state = "activate_podcast_menu"


    def app_state_MUSIC_MENU(self):
        if self.__app_state == "activate_espaniola_menu":
            self.__app_state = "activating_espaniola_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_espaniola_menu()
        elif self.__app_state == "activate_romantica_menu":
            self.__app_state = "activating_romantica_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_romantica_menu()
        elif self.__app_state == "activate_clasica_menu":
            self.__app_state = "activating_clasica_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_clasica_menu()
        elif self.__app_state == "activate_contemporanea_menu":
            self.__app_state = "activating_contemporanea_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_contemporanea_menu()

    def app_state_PODCAST_MENU(self):
        if self.__app_state == "activate_noticias_menu":
            self.__app_state = "activating_noticias_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_actualidad_menu()
        elif self.__app_state == "activate_deportes_menu":
            self.__app_state = "activating_deportes_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_deportes_menu()
        elif self.__app_state == "activate_historias_menu":
            self.__app_state = "activating_historias_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_historias_menu()
        elif self.__app_state == "activate_comedias_menu":
            self.__app_state = "activating_comedias_menu"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_comedia_menu()


    def app_state_M_ESPANIOLA(self):
        if self.__app_state == "play_coplas_music":
            self.__app_state = "playing_coplas_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_coplas_music()
        elif self.__app_state == "play_sevillanas_music":
            self.__app_state = "playing_sevillanas_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_sevillanas_music()
        elif self.__app_state == "play_flamenco_music":
            self.__app_state = "playing_flamenco_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_flamenco_music()
        elif self.__app_state == "play_jotas_music":
            self.__app_state = "playing_jotas_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_jotas_music()
        elif self.__app_state == "play_zarzuelas_music":
            self.__app_state = "playing_zarzuelas_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_zarzuelas_music
    def app_state_M_ROMANTICA(self):
        if self.__app_state == "play_baladas_music":
            self.__app_state = "playing_baladas_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_baladas_music()
        elif self.__app_state == "play_boleros_music":
            self.__app_state = "playing_boleros_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_boleros_music()
        elif self.__app_state == "play_tangos_music":
            self.__app_state = "playing_tangos_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_tangos_music()
        elif self.__app_state == "play_cantantes_recuerdo_music":
            self.__app_state = "playing_cantantes_recuerdo_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_cantantes_recuerdo_music()
        elif self.__app_state == "play_canciones_recuerdo_music":
            self.__app_state = "playing_canciones_recuerdo_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_canciones_recuerdo_music()
    def app_state_M_CLASICA(self):
        if self.__app_state == "play_piano_music":
            self.__app_state = "playing_piano_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_piano_music()
        elif self.__app_state == "play_grandes_clasicos_music":
            self.__app_state = "playing_grandes_clasicos_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_grandes_clasicos_music()
        elif self.__app_state == "play_orquesta_music":
            self.__app_state = "playing_orquesta_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_orquesta_music()
        elif self.__app_state == "play_violin_music":
            self.__app_state = "playing_violin_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_violin_music()
        elif self.__app_state == "play_relajante_music":
            self.__app_state = "playing_relajante_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_relajante_music()
    def app_state_M_CONTEMPORANEA(self):
        if self.__app_state == "play_rock_music":
            self.__app_state = "playing_rock_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_rock_music()
        elif self.__app_state == "play_pop_music":
            self.__app_state = "playing_pop_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_pop_music()
        elif self.__app_state == "play_jazz_music":
            self.__app_state = "playing_jazz_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_jazz_music()
        elif self.__app_state == "play_blues_music":
            self.__app_state = "playing_blues_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_blues_music()
        elif self.__app_state == "play_bandas_sonoras_music":
            self.__app_state = "playing_bandas_sonoras_music"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_bandas_sonoras_music()

    def app_state_P_ACTUALIDAD(self):
        if self.__app_state == "play_p1_actualidad":
            self.__app_state = "playing_p1_actualidad"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_a1_podcast()
        elif self.__app_state == "play_p2_actualidad":
            self.__app_state = "playing_p2_actualidad"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_a2_podcast()
        elif self.__app_state == "play_p3_actualidad":
            self.__app_state = "playing_p3_actualidad"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_a3_podcast()
        elif self.__app_state == "play_p4_actualidad":
            self.__app_state = "playing_p4_actualidad"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_a4_podcast()
        elif self.__app_state == "play_p5_actualidad":
            self.__app_state = "playing_p5_actualidad"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_a5_podcast()
    def app_state_P_DEPORTES(self):
        if self.__app_state == "play_p1_deportes":
            self.__app_state = "playing_p1_deportes"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_d1_podcast()
        elif self.__app_state == "play_p2_deportes":
            self.__app_state = "playing_p2_deportes"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_d2_podcast()
        elif self.__app_state == "play_p3_deportes":
            self.__app_state = "playing_p3_deportes"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_d3_podcast()
        elif self.__app_state == "play_p4_deportes":
            self.__app_state = "playing_p4_deportes"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_d4_podcast()
        elif self.__app_state == "play_p5_deportes":
            self.__app_state = "playing_p5_deportes"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_d5_podcast()
    def app_state_P_HISTORIAS(self):
        if self.__app_state == "play_p1_historias":
            self.__app_state = "playing_p1_historias"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_h1_podcast()
        elif self.__app_state == "play_p2_historias":
            self.__app_state = "playing_p2_historias"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_h2_podcast()
        elif self.__app_state == "play_p3_historias":
            self.__app_state = "playing_p3_historias"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_h3_podcast()
        elif self.__app_state == "play_p4_historias":
            self.__app_state = "playing_p4_historias"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_h4_podcast()
        elif self.__app_state == "play_p5_historias":
            self.__app_state = "playing_p5_historias"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_h5_podcast()
    def app_state_P_COMEDIA(self):
        if self.__app_state == "play_p1_comedia":
            self.__app_state = "playing_p1_comedia"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_c1_podcast()
        elif self.__app_state == "play_p2_comedia":
            self.__app_state = "playing_p2_comedia"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_c2_podcast()
        elif self.__app_state == "play_p3_comedia":
            self.__app_state = "playing_p3_comedia"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_c3_podcast()
        elif self.__app_state == "play_p4_comedia":
            self.__app_state = "playing_p4_comedia"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_c4_podcast()
        elif self.__app_state == "play_p5_comedia":
            self.__app_state = "playing_p5_comedia"
            rospy.loginfo("new __app_state: %s", self.__app_state)
            self.app_state_play_c5_podcast()

    def state_transition(self):
        if self.__app_state == "executing_welcome":
            self.__app_state = "activate_main_menu"

    def main_menu_transition(self, ans):
        if self.__app_menu == "MAIN_MENU":
            if ans == "música":
                self.__app_state = "activate_music_menu"
            elif ans == "podcast":
                self.__app_state = "activate_podcast_menu"
            elif ans == "salir":
                self.__app_state = "close_app"


    # CA RESULT MENU TRANSITION #
    def menu_transition(self, ans):
        if self.__app_menu == "MAIN_MENU":
            self.main_menu_transition(ans)
        elif self.__app_menu == "MUSIC_MENU":
            self.music_menu_transition(ans)
        elif self.__app_menu == "PODCAST_MENU":
            self.podcast_menu_transition(ans)
        elif self.__app_menu == "ESPANIOLA_MENU":
            self.espaniola_menu_transition(ans)
        elif self.__app_menu == "ROMANTICA_MENU":
            self.romantica_menu_transition(ans)
        elif self.__app_menu == "CLASICA_MENU":
            self.clasica_menu_transition(ans)
        elif self.__app_menu == "CONTEMPORANEA_MENU":
            self.contemporanea_menu_transition(ans)
        elif self.__app_menu == "NOTICIAS_MENU":
            self.actualidad_menu_transition(ans)
        elif self.__app_menu == "DEPORTES_MENU":
            self.deportes_menu_transition(ans)
        elif self.__app_menu == "HISTORIAS_MENU":
            self.historias_menu_transition(ans)
        elif self.__app_menu == "COMEDIA_MENU":
            self.comedia_menu_transition(ans)

    def music_menu_transition(self, ans):
        if self.__app_menu == "MUSIC_MENU":
            if ans == "española":
                self.__app_state = "activate_espaniola_menu"
            elif ans == "romántica y del recuerdo":
                self.__app_state = "activate_romantica_menu"
            elif ans == "clásica":
                self.__app_state = "activate_clasica_menu"
            elif ans == "contemporánea":
                self.__app_state = "activate_contemporanea_menu"
            elif ans == "tu selección":
                self.__app_state = "play_your_selection_menu"
            elif ans == "atrás":
                self.__app_state = "back_for_music_menu"
    def podcast_menu_transition(self, ans):
        if self.__app_menu == "PODCAST_MENU":
            if ans == "actualidad":
                self.__app_state = "activate_noticias_menu"
            elif ans == "deportes":
                self.__app_state = "activate_deportes_menu"
            elif ans == "historias":
                self.__app_state = "activate_historias_menu"
            elif ans == "comedia":
                self.__app_state = "activate_comedias_menu"
            elif ans == "misas":
                self.__app_state = "play_misas_menu"
            elif ans == "atrás":
                self.__app_state = "back_for_podcast_menu"
    def espaniola_menu_transition(self, ans):
        if self.__app_menu == "ESPANIOLA_MENU":
            if ans == "coplas y paso doble":
                self.__app_state = "play_coplas_music"
            elif ans == "sevillanas":
                self.__app_state = "play_sevillanas_music"
            elif ans == "flamenco":
                self.__app_state = "play_flamenco_music"
            elif ans == "jotas":
                self.__app_state = "play_jotas_music"
            elif ans == "zarzuela":
                self.__app_state = "play_zarzuelas_music"
            elif ans == "atrás":
                self.__app_state = "back_for_espaniola_menu"
    def romantica_menu_transition(self, ans):
        if self.__app_menu == "ROMANTICA_MENU":
            if ans == "baladas":
                self.__app_state = "play_baladas_music"
            elif ans == "boleros y música mexicana":
                self.__app_state = "play_boleros_music"
            elif ans == "tangos":
                self.__app_state = "play_tangos_music"
            elif ans == "cantantes del recuerdo":
                self.__app_state = "play_cantantes_recuerdo_music"
            elif ans == "canciones del recuerdo":
                self.__app_state = "play_canciones_recuerdo_music"
            elif ans == "atrás":
                self.__app_state = "back_for_romantica_menu"
    def clasica_menu_transition(self, ans):
        rospy.loginfo("clasica_menu_transition")
        if self.__app_menu == "CLASICA_MENU":
            if ans == "piano":
                self.__app_state = "play_piano_music"
            elif ans == "grandes clásicos":
                self.__app_state = "play_grandes_clasicos_music"
            elif ans == "orquesta sinfónica":
                self.__app_state = "play_orquesta_music"
            elif ans == "violín":
                self.__app_state = "play_violin_music"
            elif ans == "relajante":
                self.__app_state = "play_relajante_music"
            elif ans == "atrás":
                self.__app_state = "back_for_clasica_menu"
    def contemporanea_menu_transition(self, ans):
        if self.__app_menu == "CONTEMPORANEA_MENU":
            if ans == "rock":
                self.__app_state = "play_rock_music"
            elif ans == "pop español":
                self.__app_state = "play_pop_music"
            elif ans == "jazz":
                self.__app_state = "play_jazz_music"
            elif ans == "blues":
                self.__app_state = "play_blues_music"
            elif ans == "bandas sonoras":
                self.__app_state = "play_bandas_sonoras_music"
            elif ans == "atrás":
                self.__app_state = "back_for_contemporanea_menu"
    def actualidad_menu_transition(self, ans):
        if self.__app_menu == "NOTICIAS_MENU":
            if ans == "es la mañana de federico":
                self.__app_state = "play_p1_actualidad"
            elif ans == "más de uno":
                self.__app_state = "play_p2_actualidad"
            elif ans == "la brújula":
                self.__app_state = "play_p3_actualidad"
            elif ans == "hoy por hoy":
                self.__app_state = "play_p4_actualidad"
            elif ans == "las noticias de la ser":
                self.__app_state = "play_p5_actualidad"
            elif ans == "atrás":
                self.__app_state = "back_for_actualidad_menu"
    def deportes_menu_transition(self, ans):
        if self.__app_menu == "DEPORTES_MENU":
            if ans == "el larguero":
                self.__app_state = "play_p1_deportes"
            elif ans == "charlas de fútbol":
                self.__app_state = "play_p2_deportes"
            elif ans == "charlas daily":
                self.__app_state = "play_p3_deportes"
            elif ans == "ración de nba":
                self.__app_state = "play_p4_deportes"
            elif ans == "play futbol":
                self.__app_state = "play_p5_deportes"
            elif ans == "atrás":
                self.__app_state = "back_for_deportes_menu"
    def historias_menu_transition(self, ans):
        if self.__app_menu == "HISTORIAS_MENU":
            if ans == "el punto sobre la historia":
                self.__app_state = "play_p1_historias"
            elif ans == "ted en español":
                self.__app_state = "play_p2_historias"
            elif ans == "se regalan dudas":
                self.__app_state = "play_p3_historias"
            elif ans == "ser historias":
                self.__app_state = "play_p4_historias"
            elif ans == "¿me lees un cuento?":
                self.__app_state = "play_p5_historias"
            elif ans == "atrás":
                self.__app_state = "back_for_historias_menu"
    def comedia_menu_transition(self, ans):
        if self.__app_menu == "COMEDIA_MENU":
            if ans == "nadie sabe nada":
                self.__app_state = "play_p1_comedia"
            elif ans == "la vida moderna":
                self.__app_state = "play_p2_comedia"
            elif ans == "escuela de nada":
                self.__app_state = "play_p3_comedia"
            elif ans == "la lengua moderna":
                self.__app_state = "play_p4_comedia"
            elif ans == "el humano es un animal":
                self.__app_state = "play_p5_comedia"
            elif ans == "atrás":
                self.__app_state = "back_for_comedia_menu"


    ## @brief Send a CA message
    ## @param ca_type: sentence or question
    ## @param etts_type: type of sentence or question   
    def say_ca_msg(self, t=None, ca_type=None, etts_type=None):

        if ca_type == 'sentence':
            ca_msg = makeCA_etts_info(t, emitter=pkg_name)

        rospy.loginfo("Adding __active_cas[%s]", ("ca_" + ca_msg.ca_name))
        self.__active_cas.append("ca_" + ca_msg.ca_name)

        rospy.loginfo("[Sending CA %s ]", ca_type)
        self.__pub_ca.publish(ca_msg)


    ## @brief Send the CA message (tablet menu)
    ## @param msg_type: kind of menu
    def tablet_ca_msg(self, t=None, msg_type=None, menu_value=None, menu_type=None):

        ca_msg = makeCA_tablet_question(menu_value=menu_value, 
            menu_type=menu_type, 
            etts_text=t, 
            emitter=pkg_name, 
            answer_time=10)

        rospy.loginfo("Adding __active_cas[%s]", ("ca_" + ca_msg.ca_name))
        self.__active_cas.append("ca_" + ca_msg.ca_name)

        rospy.logdebug("[Sending CA %s ]", msg_type)
        self.__pub_ca.publish(ca_msg)




    def app_state_music_menu(self):
        self.__pub_to_app.publish("R_ORDER/MENU_MUSICA")
        t = "Elige por pantalla el género de música que quieres escuchar."
        menu_value = "Española|Romántica y del Recuerdo|Clásica|Contemporánea|Tu Selección|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="music_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "MUSIC_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_podcast_menu(self):
        self.__pub_to_app.publish("R_ORDER/MENU_PODCAST")
        t = "Elige por pantalla el tipo de podcast que quieres escuchar."
        menu_value = "Actualidad|Deportes|Historias|Comedia|Misas|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="podcast_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "PODCAST_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True

    def app_state_espaniola_menu(self):
        self.__pub_to_app.publish("R_ORDER/M_ESPANIOLA")
        t = "Elige por pantalla el género de música española que quieres escuchar."
        menu_value = "Coplas y Paso Doble|Sevillanas|Flamenco|Jotas|Zarzuelas|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="music_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "ESPANIOLA_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_romantica_menu(self):
        self.__pub_to_app.publish("R_ORDER/M_ROMANTICA")
        t = "Elige por pantalla el tipo de música romántica y del recuerdo que quieres escuchar."
        menu_value = "Baladas|Boleros y Música Mexicana|Tangos|Cantantes del Recuerdo|Canciones del Recuerdo|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="music_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "ROMANTICA_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_clasica_menu(self):
        self.__pub_to_app.publish("R_ORDER/M_CLASICA")
        t = "Elige por pantalla el tipo de música clasica que quieres escuchar."
        menu_value = "Piano|Grandes Clásicos|Orquesta Sinfónica|Violín|Relajante|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="music_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "CLASICA_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_contemporanea_menu(self):
        self.__pub_to_app.publish("R_ORDER/M_CONTEMPORANEA")
        t = "Elige por pantalla el tipo de música contemporánea que quieres escuchar."
        menu_value = "Rock|Pop Español|Jazz|Blues|Bandas Sonoras|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="music_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "CONTEMPORANEA_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True

    def app_state_actualidad_menu(self):
        self.__pub_to_app.publish("R_ORDER/P_NOTICIAS")
        t = "Elige por pantalla el tipo de podcast de actualidad que quieres escuchar."
        menu_value = "Es la mañana de Federico|Más de Uno|La Brújula|Hoy por Hoy|Las noticias de la Ser|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="podcast_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "NOTICIAS_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_deportes_menu(self):
        self.__pub_to_app.publish("R_ORDER/P_DEPORTES")
        t = "Elige por pantalla el tipo de podcast de deportes que quieres escuchar."
        menu_value = "El Larguero|Charlas de Fútbol|Charlas Daily|Ración de NBA|Play Fútbol|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="podcast_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "DEPORTES_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_historias_menu(self):
        self.__pub_to_app.publish("R_ORDER/P_HISTORIAS")
        t = "Elige por pantalla el tipo de podcast de historias que quieres escuchar."
        menu_value = "El punto sobre la historia|TED en Español|Se regalan dudas|SER Historias|¿Me lees un cuento?|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="podcast_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "HISTORIAS_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True
    def app_state_comedia_menu(self):
        self.__pub_to_app.publish("R_ORDER/P_COMEDIA")
        t = "Elige por pantalla el tipo de podcast de comedia que quieres escuchar."
        menu_value = "Nadie sabe nada|La vida moderna|Escuela de nada|La lengua moderna|El humano es un animal|Atrás"
        menu_type = "text"
        self.tablet_ca_msg(t=t, msg_type="podcast_menu", menu_value=menu_value, menu_type=menu_type)
        self.__app_menu = "COMEDIA_MENU"
        rospy.loginfo("__app_menu: " + self.__app_menu)
        self.__waiting_answer = True

# MUSIC ESPANIOLA SELECTION #
    def app_state_play_coplas_music(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta de las coplas y el paso doble.', ca_type='sentence', etts_type='w_play_coplas')
        self.__waiting_answer = True

    def app_state_play_sevillanas_music(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta de las sevillanas.', ca_type='sentence', etts_type='w_play_sevillanas')
        self.__waiting_answer = True

    def app_state_play_flamenco_music(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta del flamenco.', ca_type='sentence', etts_type='w_play_flamenco')
        self.__waiting_answer = True

    def app_state_play_jotas_music(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta de las jotas.', ca_type='sentence', etts_type='w_play_jotas')
        self.__waiting_answer = True

    def app_state_play_zarzuelas_music(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta de las zarzuelas.', ca_type='sentence', etts_type='w_play_zarzuelas')
        self.__waiting_answer = True

# MUSIC ROMANTICA SELECTION #
    def app_state_play_baladas_music(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta de las baladas.', ca_type='sentence', etts_type='w_play_baladas')
        self.__waiting_answer = True

    def app_state_play_boleros_music(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta de los boleros.', ca_type='sentence', etts_type='w_play_boleros')
        self.__waiting_answer = True

    def app_state_play_tangos_music(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta de los tangos.', ca_type='sentence', etts_type='w_play_tangos')
        self.__waiting_answer = True

    def app_state_play_cantantes_recuerdo_music(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta de los cantantes del recuerdo.', ca_type='sentence', etts_type='w_play_cantantes_r')
        self.__waiting_answer = True

    def app_state_play_canciones_recuerdo_music(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta de las canciones del recuerdo.', ca_type='sentence', etts_type='w_play_canciones_r')
        self.__waiting_answer = True

# MUSIC CLASICA SELECTION #
    def app_state_play_piano_music(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta de las canciones de piano.', ca_type='sentence', etts_type='w_play_piano')
        self.__waiting_answer = True

    def app_state_play_grandes_clasicos_music(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta de los grandes clásicos.', ca_type='sentence', etts_type='w_play_g_clasicos')
        self.__waiting_answer = True

    def app_state_play_orquesta_music(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta de las canciones de orquesta sinfónica.', ca_type='sentence', etts_type='w_play_orquesta')
        self.__waiting_answer = True

    def app_state_play_violin_music(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta de las canciones de violín.', ca_type='sentence', etts_type='w_play_violin')
        self.__waiting_answer = True

    def app_state_play_relajante_music(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta de la música relajante.', ca_type='sentence', etts_type='w_play_relajante')
        self.__waiting_answer = True

# MUSIC CONTEMPORANEA SELECTION #
    def app_state_play_rock_music(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta de las canciones de rock.', ca_type='sentence', etts_type='w_play_rock')
        self.__waiting_answer = True

    def app_state_play_pop_music(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta de las canciones de pop español.', ca_type='sentence', etts_type='w_play_pop')
        self.__waiting_answer = True

    def app_state_play_jazz_music(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta de las canciones de jazz.', ca_type='sentence', etts_type='w_play_jazz')
        self.__waiting_answer = True

    def app_state_play_blues_music(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta de las canciones de blues.', ca_type='sentence', etts_type='w_play_blues')
        self.__waiting_answer = True

    def app_state_play_bandas_sonoras_music(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta de las bandas sonoras.', ca_type='sentence', etts_type='w_play_bandas_s')
        self.__waiting_answer = True

# PODCAST ACTUALIDAD SELECTION #
    def app_state_play_a1_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta del podcast de actualidad.', ca_type='sentence', etts_type='w_play_a1')
        self.__waiting_answer = True

    def app_state_play_a2_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta del podcast de actualidad.', ca_type='sentence', etts_type='w_play_a2')
        self.__waiting_answer = True

    def app_state_play_a3_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta del podcast de actualidad.', ca_type='sentence', etts_type='w_play_a3')
        self.__waiting_answer = True

    def app_state_play_a4_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta del podcast de actualidad.', ca_type='sentence', etts_type='w_play_a4')
        self.__waiting_answer = True

    def app_state_play_a5_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta del podcast de actualidad.', ca_type='sentence', etts_type='w_play_a5')
        self.__waiting_answer = True

# PODCAST DEPORTES SELECTION #
    def app_state_play_d1_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta del podcast de deportes.', ca_type='sentence', etts_type='w_play_d1')
        self.__waiting_answer = True

    def app_state_play_d2_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta del podcast de deportes.', ca_type='sentence', etts_type='w_play_d2')
        self.__waiting_answer = True

    def app_state_play_d3_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta del podcast de deportes.', ca_type='sentence', etts_type='w_play_d3')
        self.__waiting_answer = True

    def app_state_play_d4_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta del podcast de deportes.', ca_type='sentence', etts_type='w_play_d4')
        self.__waiting_answer = True

    def app_state_play_d5_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta del podcast de deportes.', ca_type='sentence', etts_type='w_play_d5')
        self.__waiting_answer = True

# PODCAST HISTORIAS SELECTION #
    def app_state_play_h1_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta del podcast de historias.', ca_type='sentence', etts_type='w_play_h1')
        self.__waiting_answer = True

    def app_state_play_h2_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta del podcast de historias.', ca_type='sentence', etts_type='w_play_h2')
        self.__waiting_answer = True

    def app_state_play_h3_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta del podcast de historias.', ca_type='sentence', etts_type='w_play_h3')
        self.__waiting_answer = True

    def app_state_play_h4_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta del podcast de historias.', ca_type='sentence', etts_type='w_play_h4')
        self.__waiting_answer = True

    def app_state_play_h5_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta del podcast de historias.', ca_type='sentence', etts_type='w_play_h5')
        self.__waiting_answer = True

# PODCAST COMEDIA SELECTION #
    def app_state_play_c1_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/1")
        self.say_ca_msg(t='Disfruta del podcast de comedia.', ca_type='sentence', etts_type='w_play_c1')
        self.__waiting_answer = True

    def app_state_play_c2_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/2")
        self.say_ca_msg(t='Disfruta del podcast de comedia.', ca_type='sentence', etts_type='w_play_c2')
        self.__waiting_answer = True

    def app_state_play_c3_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/3")
        self.say_ca_msg(t='Disfruta del podcast de comedia.', ca_type='sentence', etts_type='w_play_c3')
        self.__waiting_answer = True

    def app_state_play_c4_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/4")
        self.say_ca_msg(t='Disfruta del podcast de comedia.', ca_type='sentence', etts_type='w_play_c4')
        self.__waiting_answer = True

    def app_state_play_c5_podcast(self):
        self.__pub_to_app.publish("R_SELECTION/5")
        self.say_ca_msg(t='Disfruta del podcast de comedia.', ca_type='sentence', etts_type='w_play_c5')
        self.__waiting_answer = True