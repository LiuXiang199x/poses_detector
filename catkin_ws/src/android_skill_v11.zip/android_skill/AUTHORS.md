# Authors and Contributors

sleeping_skill package was designed and developed by the Social Robots Group at Robotics Lab, UC3M (Spain).

### Current Team

* [marcosm](http://asimov.uc3m.es/marcosm) (developer, maintainer)
* [Miguel A. Salichs](http://roboticslab.uc3m.es/roboticslab/people/ma-salichs) (director)


### Thanks

[See all Github contributors](http://asimov.uc3m.es/common/sleeping_skill/contributors)

